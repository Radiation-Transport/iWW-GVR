# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['iww_gvr', 'iww_gvr.utils']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=8.3.2,<9.0.0',
 'PyQt5>=5.15.4,<6.0.0',
 'matplotlib>=3.4.3,<4.0.0',
 'pyevtk>=1.4.1,<2.0.0',
 'scipy>=1.7.1,<2.0.0',
 'tqdm>=4.62.3,<5.0.0',
 'vtk>=9.0.3,<10.0.0']

setup_kwargs = {
    'name': 'iww-gvr',
    'version': '1.1.8',
    'description': 'Weight window Manipulator & Global Variance Reduction Tool',
    'long_description': None,
    'author': 'Marco Fabbri',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
