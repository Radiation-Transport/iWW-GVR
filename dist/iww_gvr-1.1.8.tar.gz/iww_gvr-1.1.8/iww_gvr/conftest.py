import sys

collect_ignore = ["__main__.py", "__init__.py", "__version__.py"]
